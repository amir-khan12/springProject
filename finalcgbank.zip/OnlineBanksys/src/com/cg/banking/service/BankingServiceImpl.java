package com.cg.banking.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.StaticApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.banking.dao.IBankingDao;
import com.cg.banking.dto.Admin;
import com.cg.banking.dto.Transcation;

@Service
@Transactional
public class BankingServiceImpl implements IBankingService {
	@Autowired
	IBankingDao dao;
	
	private static final String key= "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789#$_*&@!";
	@Override
	public boolean checkL(String adminId, String password)
	{
		if(adminId.equals("admin") && password.equals("123"))
		{
			
			return true;
		}
		else
		{

			
			return false;
		}
		
	}
	
	
	
	@Override
	public void addDetails(Admin admin) {
		admin.setOpenDate(new Date());
		StringBuilder builder = new StringBuilder();
		int count=8;
		while (count-- != 0) {
		int index = (int)(Math.random()*key.length());
		builder.append(key.charAt(index));
		}
		admin.setPassword(builder.toString());
		
		dao.addDetails(admin);
	}

	@Override
	public ArrayList<Transcation> retrieveDaily() {
	
		return dao.retrieveDaily();
	}

	@Override
	public ArrayList<Transcation> retrieveMonthly() {
		
		return dao.retrieveMonthly();
	}

	@Override
	public ArrayList<Transcation> retrieveQuarterly() {
		
		return dao.retrieveQuarterly();
	}

	@Override
	public ArrayList<Transcation> retrieveYearly() {
		
		return dao.retrieveYearly();
	}

}
