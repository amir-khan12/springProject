package com.cg.banking.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.banking.dto.Admin;
import com.cg.banking.dto.Transcation;
@Repository
public class BankingDaoImpl implements IBankingDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
		
		@Override
		public void addDetails(Admin admin) {
			// TODO Auto-generated method stub
			entityManager.persist(admin);
			entityManager.flush();
		}


		@Override
		public ArrayList<Transcation> retrieveDaily() {
			TypedQuery<Transcation> query = entityManager.createQuery("SELECT a FROM Transcation a WHERE (trunc(sysdate)=trunc(DateOfTransaction))", Transcation.class);
			ArrayList<Transcation> list=(ArrayList<Transcation>) query.getResultList();
			if(list.isEmpty()){
			
				return null;
			}
			return list;
		}

		@Override
		public ArrayList<Transcation> retrieveMonthly() {
			TypedQuery<Transcation> query = entityManager.createQuery("SELECT a FROM Transcation a WHERE (trunc(sysdate)-trunc(DateOfTransaction)<=30)", Transcation.class);
			ArrayList<Transcation> monthList = (ArrayList<Transcation>) query.getResultList();
			if(monthList.isEmpty()){
				
				return null;
			}
			return monthList; 
		}

		@Override
		public ArrayList<Transcation> retrieveQuarterly() {
			TypedQuery<Transcation> query = entityManager.createQuery("SELECT a FROM Transcation a WHERE (trunc(sysdate)-trunc(DateOfTransaction)<=92)", Transcation.class);
			ArrayList<Transcation> quaterList = (ArrayList<Transcation>) query.getResultList();
			if(quaterList.isEmpty()){
				
				return null;
			}
			return quaterList; 
		}

		@Override
		public ArrayList<Transcation> retrieveYearly() {
			TypedQuery<Transcation> query = entityManager.createQuery("SELECT a FROM Transcation a WHERE (trunc(sysdate)-trunc(DateOfTransaction)<=365)", Transcation.class);
			ArrayList<Transcation> yearList = (ArrayList<Transcation>) query.getResultList();
			if(yearList.isEmpty()){
				
				return null;
			}
			return yearList; 
		}
}
