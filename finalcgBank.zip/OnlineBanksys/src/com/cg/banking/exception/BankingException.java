package com.cg.banking.exception;

public class BankingException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3182651296000517049L;

	public BankingException() {
		super();
	
	}

	public BankingException(String message) {
		super(message);
		
	}
	
	

}
