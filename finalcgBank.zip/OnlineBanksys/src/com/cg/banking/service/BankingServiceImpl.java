package com.cg.banking.service;

import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.banking.dao.IBankingDao;
import com.cg.banking.dto.Admin;
import com.cg.banking.dto.Transcation;
import com.cg.banking.exception.BankingException;

@Service
@Transactional
public class BankingServiceImpl implements IBankingService {
	@Autowired
	IBankingDao dao;
	
	private static final String key= "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789#$_*&@!";
	private static final String alpha ="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final String num ="0123456789";
	@Override
	public boolean checkL(String adminId, String password)
	{
		if(adminId.equals("admin") && password.equals("123"))
		{
			
			return true;
		}
		else
		{

			
			return false;
		}
		
	}
	
	
	
	@Override
	public void addDetails(Admin admin) throws BankingException{
		admin.setOpenDate(new Date());
		StringBuilder builder = new StringBuilder();
		int count=8;
		while (count-- != 0) {
		int index = (int)(Math.random()*key.length());
		builder.append(key.charAt(index));
		}
			
		admin.setPassword(builder.toString());
		
		
		StringBuilder uid = new StringBuilder();
		
		uid.append(alpha.charAt((int)(Math.random()*alpha.length())));
		count=5;
		while (count-- != 0) {
		int index = (int)(Math.random()*num.length());
		uid.append(num.charAt(index));
		}
		admin.setUserID(uid.toString());
		
		dao.addDetails(admin);
	}

	@Override
	public ArrayList<Transcation> retrieveDaily()throws BankingException {
	
		return dao.retrieveDaily();
	}

	@Override
	public ArrayList<Transcation> retrieveMonthly()throws BankingException {
		
		return dao.retrieveMonthly();
	}

	@Override
	public ArrayList<Transcation> retrieveQuarterly() throws BankingException{
		
		return dao.retrieveQuarterly();
	}

	@Override
	public ArrayList<Transcation> retrieveYearly()throws BankingException {
		
		return dao.retrieveYearly();
	}

}
