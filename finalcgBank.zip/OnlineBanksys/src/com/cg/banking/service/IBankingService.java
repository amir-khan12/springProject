package com.cg.banking.service;

import java.util.ArrayList;

import com.cg.banking.dto.Admin;
import com.cg.banking.dto.Transcation;
import com.cg.banking.exception.BankingException;

public interface IBankingService {

	public boolean checkL(String adminId, String password);
	
	void addDetails(Admin admin)throws BankingException;

	public ArrayList<Transcation> retrieveDaily()throws BankingException;

	public ArrayList<Transcation> retrieveMonthly()throws BankingException;

	public ArrayList<Transcation> retrieveQuarterly()throws BankingException;

	public ArrayList<Transcation> retrieveYearly()throws BankingException;

}
