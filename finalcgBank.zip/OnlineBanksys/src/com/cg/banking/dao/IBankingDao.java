package com.cg.banking.dao;

import java.util.ArrayList;

import com.cg.banking.dto.Admin;
import com.cg.banking.dto.Transcation;
import com.cg.banking.exception.BankingException;

public interface IBankingDao {
	
	void addDetails(Admin admin)throws BankingException;

	ArrayList<Transcation> retrieveDaily()throws BankingException;

	ArrayList<Transcation> retrieveMonthly()throws BankingException;

	ArrayList<Transcation> retrieveQuarterly()throws BankingException;

	ArrayList<Transcation> retrieveYearly()throws BankingException;

}
