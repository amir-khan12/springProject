package com.cg.banking.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.banking.dto.Admin;
import com.cg.banking.dto.Transcation;
import com.cg.banking.exception.BankingException;
@Repository
public class BankingDaoImpl implements IBankingDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
		
		@Override
		public void addDetails(Admin admin)throws BankingException {
			
			try {
				entityManager.persist(admin);
				entityManager.flush();
			} catch (Exception e) {
				new BankingException(e.getMessage());
			}
		}


		@Override
		public ArrayList<Transcation> retrieveDaily()throws BankingException {
			TypedQuery<Transcation> query = entityManager.createQuery("SELECT a FROM Transcation a WHERE (trunc(sysdate)=trunc(DateOfTransaction))", Transcation.class);
			ArrayList<Transcation> list = null;
			try {
				list = (ArrayList<Transcation>) query.getResultList();
			} catch (Exception e) {
				new BankingException(e.getMessage());
			
			}
			if(list.isEmpty()){
			
				return null;
			}
			return list;
		}

		@Override
		public ArrayList<Transcation> retrieveMonthly()throws BankingException {
			TypedQuery<Transcation> query = entityManager.createQuery("SELECT a FROM Transcation a WHERE (trunc(sysdate)-trunc(DateOfTransaction)<=30)", Transcation.class);
			ArrayList<Transcation> monthList = null;
			try {
				monthList = (ArrayList<Transcation>) query.getResultList();
			} catch (Exception e) {
				new BankingException(e.getMessage());
			}
			if(monthList.isEmpty()){
				
				return null;
			}
			return monthList; 
		}

		@Override
		public ArrayList<Transcation> retrieveQuarterly()throws BankingException {
			TypedQuery<Transcation> query = entityManager.createQuery("SELECT a FROM Transcation a WHERE (trunc(sysdate)-trunc(DateOfTransaction)<=92)", Transcation.class);
			ArrayList<Transcation> quaterList = null;
			try {
				quaterList = (ArrayList<Transcation>) query.getResultList();
			} catch (Exception e) {
				new BankingException(e.getMessage());
			}
			if(quaterList.isEmpty()){
				
				return null;
			}
			return quaterList; 
		}

		@Override
		public ArrayList<Transcation> retrieveYearly()throws BankingException {
			TypedQuery<Transcation> query = entityManager.createQuery("SELECT a FROM Transcation a WHERE (trunc(sysdate)-trunc(DateOfTransaction)<=365)", Transcation.class);
			ArrayList<Transcation> yearList = null;
			try {
				yearList = (ArrayList<Transcation>) query.getResultList();
			} catch (Exception e) {
				new BankingException(e.getMessage());
			}
			if(yearList.isEmpty()){
				
				return null;
			}
			return yearList; 
		}
}
