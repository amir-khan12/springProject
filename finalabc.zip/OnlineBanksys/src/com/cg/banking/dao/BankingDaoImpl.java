package com.cg.banking.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.banking.dto.Account;
import com.cg.banking.dto.Admin;
import com.cg.banking.dto.Transaction;
import com.cg.banking.exception.BankingException;
/**
 * @author team 5
 *
 */
@Repository
public class BankingDaoImpl implements IBankingDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
		
		/* (non-Javadoc)
		 * @see com.cg.banking.dao.IBankingDao#addDetails(com.cg.banking.dto.Account)
		 */
		@Override
		public void addDetails(Account admin)throws BankingException {
			
			try {
				entityManager.persist(admin);
				entityManager.flush();
			} catch (Exception e) {
				new BankingException(e.getMessage());
			}
		}


		/* (non-Javadoc)
		 * @see com.cg.banking.dao.IBankingDao#retrieveDaily()
		 */
		@Override
		public ArrayList<Transaction> retrieveDaily()throws BankingException {
			TypedQuery<Transaction> query = entityManager.createQuery("SELECT a FROM Transaction a WHERE (trunc(sysdate)=trunc(DateOfTransaction))", Transaction.class);
			ArrayList<Transaction> list = null;
			try {
				list = (ArrayList<Transaction>) query.getResultList();
			} catch (Exception e) {
				new BankingException(e.getMessage());
			
			}
			if(list.isEmpty()){
			
				return null;
			}
			return list;
		}

		/* (non-Javadoc)
		 * @see com.cg.banking.dao.IBankingDao#retrieveMonthly()
		 */
		@Override
		public ArrayList<Transaction> retrieveMonthly()throws BankingException {
			TypedQuery<Transaction> query = entityManager.createQuery("SELECT a FROM Transaction a WHERE (trunc(sysdate)-trunc(DateOfTransaction)<=30)", Transaction.class);
			ArrayList<Transaction> monthList = null;
			try {
				monthList = (ArrayList<Transaction>) query.getResultList();
			} catch (Exception e) {
				new BankingException(e.getMessage());
			}
			if(monthList.isEmpty()){
				
				return null;
			}
			return monthList; 
		}

		/* (non-Javadoc)
		 * @see com.cg.banking.dao.IBankingDao#retrieveQuarterly()
		 */
		@Override
		public ArrayList<Transaction> retrieveQuarterly()throws BankingException {
			TypedQuery<Transaction> query = entityManager.createQuery("SELECT a FROM Transaction a WHERE (trunc(sysdate)-trunc(DateOfTransaction)<=92)", Transaction.class);
			ArrayList<Transaction> quaterList = null;
			try {
				quaterList = (ArrayList<Transaction>) query.getResultList();
			} catch (Exception e) {
				new BankingException(e.getMessage());
			}
			if(quaterList.isEmpty()){
				
				return null;
			}
			return quaterList; 
		}

		/* (non-Javadoc)
		 * @see com.cg.banking.dao.IBankingDao#retrieveYearly()
		 */
		@Override
		public ArrayList<Transaction> retrieveYearly()throws BankingException {
			TypedQuery<Transaction> query = entityManager.createQuery("SELECT a FROM Transaction a WHERE (trunc(sysdate)-trunc(DateOfTransaction)<=365)", Transaction.class);
			ArrayList<Transaction> yearList = null;
			try {
				yearList = (ArrayList<Transaction>) query.getResultList();
			} catch (Exception e) {
				new BankingException(e.getMessage());
			}
			if(yearList.isEmpty()){
				
				return null;
			}
			return yearList; 
		}


		/* (non-Javadoc)
		 * @see com.cg.banking.dao.IBankingDao#checkValidAdmin(java.lang.String, java.lang.String)
		 */
		@Override
		public Admin checkValidAdmin(String adminId, String password) {
			Admin admin=entityManager.find(Admin.class, adminId);
			return admin;
		}


		/* (non-Javadoc)
		 * @see com.cg.banking.dao.IBankingDao#getAdmin(java.lang.String)
		 */
		@Override
		public Admin getAdmin(String adminId) {
			Admin admin=entityManager.find(Admin.class, adminId);
			return admin;
		}


		/* (non-Javadoc)
		 * @see com.cg.banking.dao.IBankingDao#changePassword(com.cg.banking.dto.Admin)
		 */
		@Override
		public void changePassword(Admin admin) {
				Admin admin1=entityManager.find(Admin.class, admin.getAdminId());
				admin1.setPassword(admin.getPassword());
					entityManager.merge(admin1);	
					
			
		}
}
