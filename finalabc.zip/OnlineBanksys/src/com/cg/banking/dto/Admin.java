package com.cg.banking.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin")

public class Admin {
	@Id
	private String adminId;

	
	private String password;
	
	private String question;
	private String answer;
	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public Admin() {
		super();
	}
	public Admin(String adminId, String password, String question, String answer) {
		super();
		this.adminId = adminId;
		this.password = password;
		this.question = question;
		this.answer = answer;
	}
	
	
	
	
}
