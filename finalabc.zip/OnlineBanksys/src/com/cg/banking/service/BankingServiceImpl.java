package com.cg.banking.service;

import java.util.ArrayList;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.banking.dao.IBankingDao;
import com.cg.banking.dto.Account;
import com.cg.banking.dto.Admin;
import com.cg.banking.dto.Transaction;
import com.cg.banking.exception.BankingException;

/**
 * @author team 5
 *
 */
@Service
@Transactional
public class BankingServiceImpl implements IBankingService {
	/**
	 * 
	 */
	@Autowired
	IBankingDao dao;
	
	/**
	 * 
	 */
	private static final String key= "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789#$_*&@!";
	/**
	 * 
	 */
	private static final String alpha ="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	/**
	 * 
	 */
	private static final String num ="0123456789";
	/* (non-Javadoc)
	 * @see com.cg.banking.service.IBankingService#checkL(java.lang.String, java.lang.String)
	 */
	@Override
	public boolean checkL(String adminId, String password)
	{
		
		
		Admin admin= dao.checkValidAdmin(adminId, password);
		if(admin==null){
			return false;
		}
		if(adminId.equals(admin.getAdminId()) && password.equals(admin.getPassword()))
		{
			
			return true;
		}
		else
		{			
			return false;
		}
		
		
	}
	
	
	
	/* (non-Javadoc)
	 * @see com.cg.banking.service.IBankingService#addDetails(com.cg.banking.dto.Account)
	 */
	@Override
	public void addDetails(Account admin) throws BankingException{
		admin.setOpenDate(new Date());
		StringBuilder builder = new StringBuilder();
		int count=8;
		while (count-- != 0) {
		int index = (int)(Math.random()*key.length());
		builder.append(key.charAt(index));
		}
			
		admin.setPassword(builder.toString());
		
		
		StringBuilder uid = new StringBuilder();
		
		uid.append(alpha.charAt((int)(Math.random()*alpha.length())));
		count=5;
		while (count-- != 0) {
		int index = (int)(Math.random()*num.length());
		uid.append(num.charAt(index));
		}
		admin.setUserID(uid.toString());
		
		dao.addDetails(admin);
	}

	/* (non-Javadoc)
	 * @see com.cg.banking.service.IBankingService#retrieveDaily()
	 */
	@Override
	public ArrayList<Transaction> retrieveDaily()throws BankingException {
	
		return dao.retrieveDaily();
	}

	/* (non-Javadoc)
	 * @see com.cg.banking.service.IBankingService#retrieveMonthly()
	 */
	@Override
	public ArrayList<Transaction> retrieveMonthly()throws BankingException {
		
		return dao.retrieveMonthly();
	}

	/* (non-Javadoc)
	 * @see com.cg.banking.service.IBankingService#retrieveQuarterly()
	 */
	@Override
	public ArrayList<Transaction> retrieveQuarterly() throws BankingException{
		
		return dao.retrieveQuarterly();
	}

	/* (non-Javadoc)
	 * @see com.cg.banking.service.IBankingService#retrieveYearly()
	 */
	@Override
	public ArrayList<Transaction> retrieveYearly()throws BankingException {
		
		return dao.retrieveYearly();
	}



	/* (non-Javadoc)
	 * @see com.cg.banking.service.IBankingService#getAdmin(java.lang.String)
	 */
	@Override
	public Admin getAdmin(String adminId) {
		
		return dao.getAdmin(adminId);
	}



	/* (non-Javadoc)
	 * @see com.cg.banking.service.IBankingService#changePassword(com.cg.banking.dto.Admin)
	 */
	@Override
	public boolean changePassword(Admin admin) {
			System.out.println(admin.getAdminId());
			
		Admin admin1=dao.getAdmin(admin.getAdminId());
		
		if(admin1==null){
			return false;
		}
	
		if(admin1.getAnswer().equals(admin.getAnswer())){
			dao.changePassword(admin);
			return true;
		}
		else{
			
			return false;
		}
		
	}

}
