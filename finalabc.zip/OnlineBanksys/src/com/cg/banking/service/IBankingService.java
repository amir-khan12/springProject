package com.cg.banking.service;

import java.util.ArrayList;

import com.cg.banking.dto.Account;
import com.cg.banking.dto.Admin;
import com.cg.banking.dto.Transaction;
import com.cg.banking.exception.BankingException;

/**
 * @author team 5
 *
 */
public interface IBankingService {

	/**
	 * @param adminId
	 * @param password
	 * @return
	 */
	public boolean checkL(String adminId, String password);
	
	/**
	 * @param admin
	 * @throws BankingException
	 */
	void addDetails(Account admin)throws BankingException;

	/**
	 * @return
	 * @throws BankingException
	 */
	public ArrayList<Transaction> retrieveDaily()throws BankingException;

	/**
	 * @return
	 * @throws BankingException
	 */
	public ArrayList<Transaction> retrieveMonthly()throws BankingException;

	/**
	 * @return
	 * @throws BankingException
	 */
	public ArrayList<Transaction> retrieveQuarterly()throws BankingException;

	/**
	 * @return
	 * @throws BankingException
	 */
	public ArrayList<Transaction> retrieveYearly()throws BankingException;
	
	/**
	 * @param adminId
	 * @return
	 */
	Admin getAdmin(String adminId);
	/**
	 * @param admin
	 * @return
	 */
	boolean changePassword(Admin admin);
}
