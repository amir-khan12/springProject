package com.cg.banking.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.dto.Account;
import com.cg.banking.dto.Admin;
import com.cg.banking.dto.Transaction;
import com.cg.banking.exception.BankingException;
import com.cg.banking.service.IBankingService;

/**
 * @author team 5
 *
 */
@Controller
public class BankingController {
	
	
	@Autowired
	private IBankingService service;

	
	
	/**
	 * @return
	 */
	public IBankingService getService() {
		return service;
	}
	/**
	 * @param service
	 */
	public void setService(IBankingService service) {
		this.service = service;
	}
	
	
	
	/**
	 * @return
	 */
	@RequestMapping("/index")
	public String index()
	{
		return "index";
	}
	/**
	 * @return
	 */
	@RequestMapping("/home")
	public String home()
	{
		return "pages/home";
	}
	/**
	 * @return
	 */
	@RequestMapping("/contact")
	public String contact()
	{
		return "pages/contact";
	}
	/*@RequestMapping("/login")
	public String start()
	{
		
		
		return "pages/adminLogin";
	}*/
	
	/**
	 * @return
	 */
	@RequestMapping("/login")
	public String start()
	{	
		
		return "pages/adminLogin";
	}
	/**
	 * @return
	 */
	@RequestMapping("/aboutus")
	public String aboutus()
	{	
		
		return "pages/aboutUs";
	}
	/**
	 * @param adminId
	 * @param request
	 * @return
	 */
	@RequestMapping("/getQuestion")
	public String getQuestion(@RequestParam("adminId") String adminId,HttpServletRequest request)
	{	
		Admin admin=service.getAdmin(adminId);
		if(admin==null){
			request.setAttribute("InvalidAdminId", "Invalid Admin Id");
			return "pages/forgot";
		}
		else{
		request.setAttribute("Admin", admin);
		return "pages/forgot";
		}
	}
	
	
	/**
	 * @return
	 */
	@RequestMapping("/forgot")
	public String forgot()
	{	
		
		return "pages/forgot";
	}
	
	/*@RequestMapping("/checkLogin")
	public String check(@RequestParam("adminId") String adminId,@RequestParam("password") String password, HttpServletRequest request)
	{
		
		
		if(service.checkL(adminId,password))
		{
		
			return "pages/home";
		
		}
		else
		{
			HttpSession session=request.getSession();
			session.setAttribute("error", "Invalid UserId or Password");
			return "pages/adminLogin";
		}
		
		
	}*/
	/**
	 * @param adminId
	 * @param password
	 * @param request
	 * @return
	 */
	@RequestMapping("/checkLogin")
	public String check(@RequestParam("adminId") String adminId,@RequestParam("password") String password, HttpServletRequest request)
	{

	
			if(service.checkL(adminId,password))
			{
				HttpSession session=request.getSession();
				session.setAttribute("adminId", adminId);
				session.setAttribute("password", password);
				return "pages/home";
			
			}
			else
			{
			
				request.setAttribute("error", "Invalid UserId or Password");
				return "pages/adminLogin";
			}
		
		
		
	}
	
	/**
	 * @param admin
	 * @param request
	 * @return
	 */
	@RequestMapping("/changePassword")
	public ModelAndView changePassword(@ModelAttribute("Admin")Admin admin, HttpServletRequest request)
	{
		ModelAndView mv=new ModelAndView();
		if(service.changePassword(admin)){
			
			mv.addObject("success", "Password Changed successfully");
				mv.setViewName("pages/adminLogin");
			
			return mv;
		}
		else{
			mv.addObject("failure", "Unable to change password since wrong answer entered");
			mv.setViewName("pages/forgot");
		
			return mv;
			
		}
		
		
		
		
	}
	
	/**
	 * @return
	 */
	@RequestMapping("/logout")
	public String out()
	{
		
		return "pages/adminLogin";
	}
	
	
	/**
	 * @param model
	 * @return
	 */
	@RequestMapping("/createAccount")
	public String goToStart(Model model){
		model.addAttribute("bean",new Account());
		return "pages/customerRegForm";
	}

	/**
	 * @param admin
	 * @param result
	 * @return
	 */
	@RequestMapping("/reg")
	public ModelAndView registration(@ModelAttribute("bean") @Valid Account admin,BindingResult result){
		if(result.hasErrors())
		{
			 
			 return new ModelAndView("pages/customerRegForm");
		}
		try {
			service.addDetails(admin);
			return new ModelAndView("pages/customerSuccess","k",admin);
		} catch (BankingException e) {
			return new ModelAndView("pages/error","error",e.getMessage());
		}
		
		
	}
/*	@RequestMapping("/viewStatement")
	public String transcation()
	{
		return "pages/Transcation";
	}
	
	@RequestMapping("/daily")
	public ModelAndView viewDailyTransactions()
	{
		
		ArrayList<Transcation> list=new ArrayList <Transcation>();
		list = service.retrieveDaily();
		return new ModelAndView("pages/Transcation","DailyTransactionsList",list);		
	}
	
	@RequestMapping("/monthly")
	public ModelAndView viewMonthlyTransactions()
	{
		
		ArrayList<Transcation> list=new ArrayList <Transcation>();
		list = service.retrieveMonthly();
		return new ModelAndView("pages/Transcation","MonthlyTransactionsList",list);		
	}
	
	@RequestMapping("/quarterly")
	public ModelAndView viewQuarterlyTransactions()
	{
		
		ArrayList<Transcation> list=new ArrayList <Transcation>();
		list = service.retrieveQuarterly();
		return new ModelAndView("pages/Transcation","QuarterlyTransactionsList",list);		
	}
	
	@RequestMapping("/yearly")
	public ModelAndView viewYearlyTransactions()
	{
		
		ArrayList<Transcation> list=new ArrayList <Transcation>();
		list = service.retrieveYearly();
		return new ModelAndView("pages/Transcation","YearlyTransactionsList",list);		
	}
*/	
	/**
	 * @return
	 */
	@RequestMapping("/viewStatement")
	public String transcation()
	{
		return "pages/bootTrans";
	}
	
	/**
	 * @return
	 */
	@RequestMapping("/daily")
	public ModelAndView viewDailyTransactions()
	{
		
		ArrayList<Transaction> list=new ArrayList <Transaction>();
		try {
			list = service.retrieveDaily();
			if(list==null){
				return new ModelAndView("pages/bootTrans","messageDaily","No Transactions made today");
			}
			else{
			return new ModelAndView("pages/bootTrans","DailyTransactionsList",list);
			}
		} catch (BankingException e) {
			return new ModelAndView("pages/error","error",e.getMessage());
		}		
	}
	
	/**
	 * @return
	 */
	@RequestMapping("/monthly")
	public ModelAndView viewMonthlyTransactions()
	{
		
		ArrayList<Transaction> list=new ArrayList <Transaction>();
		try {
			list = service.retrieveMonthly();
			if(list==null){
				return new ModelAndView("pages/bootTrans","messageMontly","No Transactions made this month");
			}
			else{
				return new ModelAndView("pages/bootTrans","MonthlyTransactionsList",list);	
			}
		} catch (BankingException e) {
			return new ModelAndView("pages/error","error",e.getMessage());
		}	
			
	}
	
	/**
	 * @return
	 */
	@RequestMapping("/quarterly")
	public ModelAndView viewQuarterlyTransactions()
	{
		
		ArrayList<Transaction> list=new ArrayList <Transaction>();
		try {
			list = service.retrieveQuarterly();
			if(list==null){
				return new ModelAndView("pages/bootTrans","messageQuaterly","No Transactions made since 3 months");
			}
			else{
				return new ModelAndView("pages/bootTrans","QuarterlyTransactionsList",list);		
			}
		} catch (BankingException e) {
			return new ModelAndView("pages/error","error",e.getMessage());
		}	
		
	}
	
	/**
	 * @return
	 */
	@RequestMapping("/yearly")
	public ModelAndView viewYearlyTransactions()
	{
		
		ArrayList<Transaction> list=new ArrayList <Transaction>();
		try {
			list = service.retrieveYearly();
			if(list==null){
				return new ModelAndView("pages/bootTrans","messageYearly","No Transactions made since a year");
			}
			else{
				return new ModelAndView("pages/bootTrans","YearlyTransactionsList",list);		
			}
		} catch (BankingException e) {
			return new ModelAndView("pages/error","error",e.getMessage());
		}	
		
	}

}
