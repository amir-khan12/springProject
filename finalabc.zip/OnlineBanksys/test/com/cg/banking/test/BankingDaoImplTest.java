/**
 * 
 */
package com.cg.banking.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.banking.dao.BankingDaoImpl;
import com.cg.banking.dao.IBankingDao;
import com.cg.banking.dto.Account;
import com.cg.banking.exception.BankingException;
import com.cg.banking.service.BankingServiceImpl;
import com.cg.banking.service.IBankingService;

/**
 * @author team 5
 *
 */
public class BankingDaoImplTest {

	Account account;
	IBankingDao bankingService;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		account=new Account();
		bankingService=new BankingDaoImpl();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		account=null;
	}

	

	/**
	 * Test method for {@link com.cg.banking.dao.BankingDaoImpl#retrieveDaily()}.
	 * @throws BankingException 
	 */
	@Test
	public void testRetrieveDaily() throws BankingException {
		assert (bankingService.retrieveDaily()) == null;
	}

	/**
	 * Test method for {@link com.cg.banking.dao.BankingDaoImpl#retrieveMonthly()}.
	 * @throws BankingException 
	 */
	@Test
	public void testRetrieveMonthly() throws BankingException {
		assert (bankingService.retrieveMonthly()) != null;
	}

	/**
	 * Test method for {@link com.cg.banking.dao.BankingDaoImpl#retrieveQuarterly()}.
	 * @throws BankingException 
	 */
	@Test
	public void testRetrieveQuarterly() throws BankingException {
		assert (bankingService.retrieveQuarterly()) != null;
	}

	/**
	 * Test method for {@link com.cg.banking.dao.BankingDaoImpl#retrieveYearly()}.
	 * @throws BankingException 
	 */
	@Test
	public void testRetrieveYearly() throws BankingException {
		assert (bankingService.retrieveYearly()) != null;
	}

}
